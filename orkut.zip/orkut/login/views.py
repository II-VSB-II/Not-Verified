from django.http import HttpResponse, HttpResponseRedirect

def index(request):
    return HttpResponse("Welcome to the tutorial.1")
